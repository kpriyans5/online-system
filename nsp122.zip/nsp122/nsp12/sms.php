<?php
session_start();
$mobile=$_SESSION['mobile'];
$email=$_SESSION['email'];
$_SESSION['email']=$email;
$mobile="$mobile";
$message="Hello!
			Welcome to Online System";
$json = json_decode(file_get_contents("https://smsapi.engineeringtgr.com/send/?Mobile=7062152865&Password=mummy1269&Message=".urlencode($message)."&To=".urlencode($mobile)."&Key=kumariE8CeZwqs2yI0oNRQO") ,true);
if ($json["status"]==="success") {
   echo "<script>
        window.location.href='mail.php'</script>";
}else{
    echo "<script>
        window.location.href='mail.php'</script>";
}
?>
 