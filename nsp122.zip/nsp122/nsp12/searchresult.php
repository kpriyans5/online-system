<!DOCTYPE html>
<html>
<head>
	<title></title>



<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
	
.box6{
width: 100%;
height: 500px;
border:2px solid black;
background-color: black;

}


</style>

</head>
<body>


<!-- 1st header box -->
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Link <span class="sr-only">(current)</span></a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="font-size: 18px">Contact:+91 969 480 7325 <span class="caret"></span></a>



          <ul class="dropdown-menu">
            <li role="separator" class="divider"></li>
            <li><a href="#">Main:+91 969 480 7325 </a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">All number & Location</a></li>
          </ul>
        </li>
      </ul>

      <form class="navbar-form navbar-left">
        <div class="form-group">
          &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 


          
          <input type="text" class="form-control" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form> &nbsp &nbsp &nbsp &nbsp &nbsp
           <ul class="nav navbar-nav navbar-center">
      <li><a href="nsp.html"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
      <button type="button" class="btn btn-default navbar-btn">GET ONLINE SYSTEM FREE</button>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>














<!--footer -->

<div class="box6" style="background-color: #00004d">

        <p style="margin-left: 650px;font-size: 25px;color: white;margin-top: 40px">SUPPORT</p>
        <p style="margin-left: 650px;font-size: 20px;color: gray">Support Center</p>


        <p style="margin-left: 150px;color: black;font-size: 30px;margin-top: -80px;color: white">ONLINE SYSTEM</p>
        <p style="margin-left: 150px;padding-right: 970px;font-size: 20px;color: gray">OS.Com is a leading learning-based development platform with multiple content. We make it easy for everyone to learn a knoweldgeble topic of subjects.<br><br>
         Increase your study, check your knoweldge, set up an online quize or just test out new ideas. The Online system  has everything you need to increase a fully personalized, high-quality knoweldge with efficient manner.</p>

           <p style="margin-left: 950px;font-size: 25px;color: white;margin-top: -380px">SOCIAL PROFILES</p>
<!-- Add font awesome icons -->
         <a href="https://www.facebook.com/profile.php" class="fa fa-facebook" style="margin-left: 940px"></a>
          <a href="https://twitter.com/#1/PRADEEP11014327" class="fa fa-twitter"></a>
          <a href="#" class="fa fa-google"></a>
           <a href="#" class="fa fa-linkedin"></a>
             <a href="#" class="fa fa-instagram"></a>
            <a href="#" class="fa fa-youtube"></a>
           <a href="#" class="fa fa-rss"></a>


</div>



</body>
</html>