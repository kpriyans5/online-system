<?php 
session_start();
if (!empty($_SESSION["NAME"])) {
  header('location:index2.php');}
  else
  {
 ?>



<!DOCTYPE html>
<html>
<head>
  <title> LOGIN FORM DESIGN</title>
  <link rel="stylesheet" type="text/css" href="NEW.css">
</head>
<body>
  <div class="loginbox">
    <img src="logo1.jpg" class="avtar">
    <h1>LOGIN HERE</h1>
    <form method="POST">
      <p>Usrename</p>
      <input type="email" name="email" id="email" placeholder="Enter email">
      <p>Password</p>
      <input type="Password" name="password" id="password" placeholder="Enter Password"">
      <input type="Submit" name="submit"  value="Login"><br>
      <a href="#"> Forgotten Password</a><br>
      
<p><a href="signup.html">NEW USER</a>
</p>
    </form>
  </div>

    <?php 
                           
                        if (isset($_POST['submit'])) {
                                
                                 $a=$_POST['email'];
                                $b=$_POST['password'];
                                $servername="localhost";
                                $username="root";
                                $password="";
                                $dbname="online";

                                $conn=mysqli_connect($servername,$username,$password,$dbname);
                          $sql="select * FROM signup WHERE email='$a' && password='$b'";
                            $result=mysqli_query($conn,$sql);
                                if(mysqli_num_rows($result)){
                                    session_start();
                                    $row=mysqli_fetch_assoc($result);
                    $_SESSION["NAME"]=$row['name'];$_SESSION["EMAIL"]=$row['email'];
                                    header('location: index2.php');
                           }
                                else
                                {
                            ?>
                            <script>
                                alert("wrong inputs");
                                </script>
                            <?php
                                }
                        }

                      }
                       ?>


 
</body>
</html>
