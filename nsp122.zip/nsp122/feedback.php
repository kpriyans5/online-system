<?php 

session_start();
$servername="localhost";
$username="root";
$password="";
$dbname="online";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if (!$conn)
 {
	die("Connection failed: " . mysqli_connect_error());
}
else
/*{
	echo "connected";
}*/
$rating=$_POST['star'];
$comment=$_POST['comment'];
$a=$_SESSION['NAME'];
$b=$_SESSION['EMAIL'];
$sql="INSERT INTO feedback(`rating`,`comment`,`name`,`email`) VALUES ('$rating','$comment','$a','$b')";
if (mysqli_query($conn,$sql))
 {
	echo "new record successfully added";
}
else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<style type="text/css">
 		body{
 			background-color: lightblue;
 		}
 	</style>
 </head>
 <body>
 
 </body>
 </html>
